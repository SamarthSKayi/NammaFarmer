import React from 'react';

export default function Testimonials() {
  return (
    <section className="testimonials" id="testimonials">
      <h2>What Farmers Are Saying</h2>
      <p>Hear from farmers who have benefitted from our app.</p>
      {/* List of testimonials */}
    </section>
  );
}
