import React from 'react';

export default function HowItWorks() {
  return (
    <section className="how-it-works" id="how-it-works">
      <h2>How It Works</h2>
      <p>Learn how to use the app to maximize your farm’s productivity.</p>
      {/* Detailed steps of how the app works */}
    </section>
  );
}
