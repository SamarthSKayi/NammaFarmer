a=4700
b=800
c=5800
print((c-a+b)/(a+b))